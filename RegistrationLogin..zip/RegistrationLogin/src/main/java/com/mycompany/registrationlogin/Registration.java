
package com.mycompany.registrationlogin;
import java.util.Scanner;
public class Registration {

//scanner for user input
Scanner input = new Scanner(System.in);

//user details
String name;
String username;
String password;
String cellphone;

// register a new user
public void registerUser() {

    //get name of user
    System.out.println("Enter your name:");
    name = input.nextLine();

    //get username
    System.out.println("Enter username:");
    username = input.nextLine();

    //get password
    System.out.println("Enter password:");
    password = input.nextLine();

    //get cellphone number
    System.out.println("Enter cellphone number:");
    cellphone = input.nextLine();

    //registration successful message
    System.out.println("Registration successful!");
    }
}
