
package com.mycompany.registrationlogin;
import java.util.Scanner;
public class Login {

//registration object
private Registration reg;

//constructor
public Login(Registration reg) {
    this.reg = reg;
}

//returns true or false
public boolean loginUser() {

    //scanner for user input
    Scanner input = new Scanner(System.in);

    //login details entered by user
    String usernameInput;
    String passwordInput;
    String cellphoneInput;

    //get username
    System.out.println("Enter Registered Username:");
    usernameInput = input.nextLine();

    //get password
    System.out.println("Enter Registered Password:");
    passwordInput = input.nextLine();

    //get cellphone number
    System.out.println("Enter Registered Cellphone Number:");
    cellphoneInput = input.nextLine();

    //check if login details match registration details
    if (usernameInput.equals(reg.username) &&
        passwordInput.equals(reg.password) &&
        cellphoneInput.equals(reg.cellphone)) {

        System.out.println(
                "Login Successful\nHello " + reg.name + ", the System welcomes you");

        return true;

    } else {

        //display login failure message
        System.out.println("Login Failed!\nIncorrect details.");

        return false;
        }
    }
}
