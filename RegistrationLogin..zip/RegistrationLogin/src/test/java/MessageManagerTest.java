

import com.mycompany.registrationlogin.Message;
import com.mycompany.registrationlogin.MessageManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageManagerTest {

    public MessageManagerTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testAddMessage() {

        MessageManager manager = new MessageManager();

        Message msg = new Message(1,"+27831234567","Did you get the cake?");

        String result = manager.addMessage(msg, "Stored");

        assertEquals("Message added successfully.",result);
    }

    @Test
    public void testDisplayLongestMessage() {

        MessageManager manager = new MessageManager();

        Message msg1 = new Message(1,"+27831234567","Did you get the cake?");

        Message msg2 = new Message(2,"+27831234567","Where are you? You are late! I have asked you to be on time.");

        manager.addMessage(msg1, "Stored");
        manager.addMessage(msg2, "Stored");

        String expected = "Where are you? You are late! I have asked you to be on time.";

        String actual = manager.displayLongestMessage();

        assertEquals(expected, actual);
    }

    @Test
    public void testSearchByMessageID() {

        MessageManager manager = new MessageManager();

        Message msg = new Message(1,"+27831234567","It is dinner time!");

        manager.addMessage(msg, "Stored");

        String expected = "Recipient: +27831234567\nMessage: It is dinner time!";

        String actual = manager.searchByMessageID(msg.getMessageID());

        assertEquals(expected, actual);
    }

    @Test
    public void testSearchByRecipient() {

        MessageManager manager = new MessageManager();

        Message msg1 = new Message(1,"+27831234567","Where are you? You are late! I have asked you to be on time.");

        Message msg2 = new Message(2,"+27831234567","Ok, I am leaving without you.");

        manager.addMessage(msg1, "Stored");
        manager.addMessage(msg2, "Stored");

        String result = manager.searchByRecipient("+27831234567");

        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));

        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessageByHash() {

        MessageManager manager = new MessageManager();

        Message msg = new Message(2,"+27831234567","Where are you? You are late! I have asked you to be on time.");

        manager.addMessage(msg, "Stored");

        String expected = "Message successfully deleted.";

        String actual = manager.deleteMessageByHash(msg.getMessageHash());

        assertEquals(expected, actual);
    }

    @Test
    public void testDisplayStoredMessages() {

        MessageManager manager = new MessageManager();

        Message msg = new Message(1,"+27831234567","Did you get the cake?");

        manager.addMessage(msg, "Stored");

        String result = manager.displayStoredMessages();

        assertTrue(result.contains("Did you get the cake?"));
    }

    @Test
    public void testDisplayReport() {

        MessageManager manager = new MessageManager();

        Message msg = new Message(1,"+27831234567","Did you get the cake?");

        manager.addMessage(msg, "Stored");

        String report = manager.displayReport();

        assertTrue(report.contains(msg.getMessageHash()));

        assertTrue(report.contains(msg.getRecipient()));

        assertTrue(report.contains(msg.getMessageText()));
    }
}