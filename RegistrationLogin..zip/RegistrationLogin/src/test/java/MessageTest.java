
import com.mycompany.registrationlogin.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testValidRecipientCell() {

        Message msg = new Message(1,"+27831234567","Hello");

        assertTrue(msg.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipientCell() {

        Message msg = new Message(1,"0831234567","Hello");

        assertFalse(msg.checkRecipientCell());
    }

    @Test
    public void testValidMessageLength() {

        Message msg = new Message(1,"+27831234567","Hello");

        assertTrue(msg.checkMessageLength());
    }

    @Test
    public void testInvalidMessageLength() {

        String longMessage = "A".repeat(251);

        Message msg = new Message(1,"+27831234567",longMessage);

        assertFalse(msg.checkMessageLength());
    }

    @Test
    public void testMessageIDGenerated() {

        Message msg = new Message(1,"+27831234567","Hello");

        assertNotNull(msg.getMessageID());
    }

    @Test
    public void testMessageHashGenerated() {

        Message msg = new Message(1,"+27831234567","Hello World");

        assertNotNull(msg.getMessageHash());
    }
}
